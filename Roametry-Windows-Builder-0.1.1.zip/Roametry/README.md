# Roametry｜跡域

把位置，變成可以設計的路徑。

Roametry 是 macOS／Windows 桌面端的 iPhone 位置情境控制台，提供地圖選點、座標設定、機車路線、多點巡迴、GPX／JSON 匯入、搖桿、歷史記錄、座標最愛、多裝置管理及手機遙控。

## 第一版功能

- iPhone／iPad USB 裝置偵測與信任狀態
- iOS 17+ RemoteXPC 通道與 Developer Disk Image 掛載
- 地圖搜尋、點選座標、貼上座標與位置預覽
- 瞬移、機車導航、路線循環、多點巡迴、隨機漫遊與搖桿
- 預設機車速度 45 km/h，可自訂 1–120 km/h
- 座標歷史、命名、分組、加入最愛、匯入與匯出
- 最多三台 iOS 裝置
- QR Code 手機遙控
- 本機資料目錄：`~/.roametry`

## 使用限制

本專案定位為 App 開發、QA、LBS、電子圍欄及個人位置情境測試工具。第三方服務可能禁止模擬定位；使用前請確認並遵守服務條款。本專案不包含反偵測、繞過反作弊或修改第三方 App 的功能。

## 開發環境

- Python 3.11+；封裝完整 iOS 18.2+ 通道時需 Python 3.13+
- Node.js 18+
- macOS 或 Windows 10／11
- 需要實機功能時，以 USB 連接並信任 iPhone

### 啟動後端

```bash
cd backend
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
python main.py
```

後端預設位於 `http://127.0.0.1:8787`。

### 啟動桌面介面

```bash
cd frontend
npm install
npm start
```

也可以在專案根目錄執行：

```bash
./scripts/start.sh
```

### 建置

```bash
# macOS Apple Silicon
./scripts/build-mac.sh --arch arm64

# macOS Intel
./scripts/build-mac.sh --arch x64

# Windows PowerShell
powershell -ExecutionPolicy Bypass -File scripts/build-win.ps1
```

Windows 封裝必須在 Windows 10／11 x64 與 Python 3.13+ 環境執行。腳本會建立 Windows 專用後端、實際啟動健康檢查，再產生 `Roametry-0.1.1-x64-Setup.exe`。也可在 GitHub Actions 手動執行 `Build Roametry for Windows` 工作流程。

## 測試

```bash
cd backend
python -m unittest discover -s tests -v

cd ../frontend
npm run build
npx vitest run
```

## 授權與來源

本專案衍生自 [ArcWayfarer](https://github.com/WeiYuanLee/ArcWayfarer)，保留原作者 Lence Lee 的 MIT 授權聲明。詳見 [LICENSE](LICENSE) 與 [NOTICE.md](NOTICE.md)。
