# Attribution

Roametry is derived from ArcWayfarer by Lence Lee and is distributed under the
MIT License included in `LICENSE`.

The Roametry name, visual identity, default motorcycle profile, data directory,
and product documentation are modifications made for this project.

ArcWayfarer project: https://github.com/WeiYuanLee/ArcWayfarer
