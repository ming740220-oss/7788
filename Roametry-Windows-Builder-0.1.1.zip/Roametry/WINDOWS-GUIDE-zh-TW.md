# Roametry｜跡域 Windows 版

Windows 10／11 x64 版已完成程式與封裝設定，功能包含機車導航、座標設定與儲存、我的最愛、路線循環、多點巡迴、搖桿、操作記錄及手機遙控。

## 為什麼目前交付的是建置套件

Roametry 的 Windows 安裝檔同時包含 Electron 桌面程式與 Python iPhone 控制後端。Python 的 Windows `.exe` 必須在 Windows 環境產生，無法在目前的 Intel Mac 環境可靠地跨系統封裝。

原始碼已附上兩種 Windows 建置方式；建置完成後會得到：

`frontend\release\Roametry-0.1.1-x64-Setup.exe`

## 方法一：在 Windows 電腦建置

先安裝：

1. Python 3.13 x64，安裝時勾選「Add Python to PATH」。
2. Node.js 22 LTS。
3. iTunes、Apple Devices，或 Apple Mobile Device Support，供 USB 辨識 iPhone。

解壓 `Roametry-Windows-Builder-0.1.1.zip`，在解壓後的 Roametry 資料夾開啟 PowerShell，執行：

```powershell
powershell -ExecutionPolicy Bypass -File scripts\build-win.ps1
```

腳本會自動安裝相依元件、建立 Windows 後端、執行啟動檢查、編譯介面並產生安裝程式，最後顯示 SHA-256 驗證碼。

## 方法二：使用 GitHub Actions

1. 把解壓後的 Roametry 原始碼放進自己的 GitHub repository。
2. 打開 repository 的「Actions」。
3. 選擇「Build Roametry for Windows」。
4. 按「Run workflow」。
5. 完成後，在該次執行頁面下載 `Roametry-0.1.1-Windows-x64` artifact。

## 安裝與連接 iPhone

1. 執行 `Roametry-0.1.1-x64-Setup.exe`，依畫面選擇安裝位置。
2. Roametry 需要系統管理員權限，以建立 iOS 17+ 定位通道。
3. 用 USB 線連接並解鎖 iPhone，在手機上選擇「信任這部電腦」。
4. 開啟 iPhone 的「設定 → 隱私權與安全性 → 開發者模式」。
5. 啟動 Roametry，等裝置出現在上方列表後即可使用。

## 使用範圍

請僅用於自己擁有或已獲授權的裝置，以及 LBS、導航、外送、打卡與地理圍欄等開發及品質測試。請遵守服務條款與當地法規；本程式不提供規避偵測或反作弊功能。
