# Builds the Roametry Windows x64 installer using PyInstaller and
# electron-builder. Run this script from Windows 10/11.
# Usage: powershell -ExecutionPolicy Bypass -File scripts/build-win.ps1

$ErrorActionPreference = "Stop"

function Assert-NativeSuccess([string]$StepName) {
    if ($LASTEXITCODE -ne 0) {
        throw "$StepName failed with exit code $LASTEXITCODE."
    }
}

# Some managed development environments set PIP_NO_INDEX=1 globally. A clean
# build venv has no packages yet, so it must be allowed to resolve the project's
# pinned requirements from the configured package index.
Remove-Item Env:PIP_NO_INDEX -ErrorAction SilentlyContinue

$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$RootDir = Resolve-Path "$ScriptDir\.."

& python -c "import sys; raise SystemExit(sys.version_info < (3, 13))"
if ($LASTEXITCODE -ne 0) {
    throw "Python 3.13 or newer is required for the complete iOS 18.2+ tunnel support."
}

Write-Host "==> Building backend for Windows"
Push-Location "$RootDir\backend"
try {
    if (Test-Path ".venv-build-win-py313") {
        Remove-Item -Recurse -Force ".venv-build-win-py313" -ErrorAction SilentlyContinue
    }
    python -m venv .venv-build-win-py313
    Assert-NativeSuccess "Creating the Python build environment"
    
    $VenvPy = ".\.venv-build-win-py313\Scripts\python.exe"

    & $VenvPy -m pip install -q --upgrade pip
    Assert-NativeSuccess "Updating pip"
    & $VenvPy -m pip install -q -r requirements.txt pyinstaller
    Assert-NativeSuccess "Installing backend build dependencies"
    & $VenvPy -m PyInstaller arcwayfarer-backend.spec --noconfirm --distpath ..\dist-py --workpath ..\build-py\backend
    Assert-NativeSuccess "Packaging the Windows backend"
} finally {
    Pop-Location
}

$BackendExe = Join-Path $RootDir "dist-py\arcwayfarer-backend\arcwayfarer-backend.exe"
if (-not (Test-Path $BackendExe)) {
    throw "Packaged Roametry backend was not created: $BackendExe"
}

Write-Host "==> Verifying packaged backend startup"
$BackendTestDir = Join-Path ([System.IO.Path]::GetTempPath()) ("roametry-backend-test-" + [guid]::NewGuid())
$BackendStdout = Join-Path $BackendTestDir "stdout.log"
$BackendStderr = Join-Path $BackendTestDir "stderr.log"
$OldApiPort = $env:ROAMETRY_API_PORT
$OldDataDir = $env:ROAMETRY_DATA_DIR
$BackendProcess = $null
New-Item -ItemType Directory -Force -Path $BackendTestDir | Out-Null

try {
    $env:ROAMETRY_API_PORT = "18787"
    $env:ROAMETRY_DATA_DIR = $BackendTestDir
    $BackendProcess = Start-Process -FilePath $BackendExe -PassThru -WindowStyle Hidden -RedirectStandardOutput $BackendStdout -RedirectStandardError $BackendStderr
    $Healthy = $false

    for ($Attempt = 0; $Attempt -lt 60; $Attempt++) {
        if ($BackendProcess.HasExited) { break }
        try {
            $Response = Invoke-WebRequest -UseBasicParsing -Uri "http://127.0.0.1:18787/health" -TimeoutSec 2
            if ($Response.StatusCode -eq 200) {
                $Healthy = $true
                break
            }
        } catch {
            Start-Sleep -Milliseconds 500
        }
    }

    if (-not $Healthy) {
        $Details = if (Test-Path $BackendStderr) { Get-Content $BackendStderr -Raw } else { "No backend log was produced." }
        throw "Packaged Roametry backend failed its startup check.`n$Details"
    }
} finally {
    if ($BackendProcess -and -not $BackendProcess.HasExited) {
        Stop-Process -Id $BackendProcess.Id -Force -ErrorAction SilentlyContinue
        Wait-Process -Id $BackendProcess.Id -ErrorAction SilentlyContinue
    }
    if ($null -eq $OldApiPort) { Remove-Item Env:ROAMETRY_API_PORT -ErrorAction SilentlyContinue } else { $env:ROAMETRY_API_PORT = $OldApiPort }
    if ($null -eq $OldDataDir) { Remove-Item Env:ROAMETRY_DATA_DIR -ErrorAction SilentlyContinue } else { $env:ROAMETRY_DATA_DIR = $OldDataDir }
    Remove-Item -Recurse -Force $BackendTestDir -ErrorAction SilentlyContinue
}

Write-Host "==> Building frontend"
Push-Location "$RootDir\frontend"
try {
    npm ci
    Assert-NativeSuccess "Installing frontend dependencies"
    npm run build
    Assert-NativeSuccess "Building the frontend"
} finally {
    Pop-Location
}

Write-Host "==> Packaging Windows installer (.exe)"
Push-Location "$RootDir\frontend"
try {
    $env:CSC_IDENTITY_AUTO_DISCOVERY = "false"
    npx electron-builder --win --x64
    Assert-NativeSuccess "Packaging the Windows installer"
} finally {
    Pop-Location
}

$Installer = Get-ChildItem "$RootDir\frontend\release\Roametry-*-x64-Setup.exe" | Sort-Object LastWriteTime | Select-Object -Last 1
if (-not $Installer) {
    throw "Roametry Windows installer was not created."
}

$InstallerHash = Get-FileHash -Algorithm SHA256 $Installer.FullName
Write-Host "==> Done: $($Installer.FullName)"
Write-Host "==> SHA-256: $($InstallerHash.Hash)"
