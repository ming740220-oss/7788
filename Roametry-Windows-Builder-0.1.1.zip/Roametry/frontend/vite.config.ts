import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'
import { resolve } from 'path'

export default defineConfig(({ mode }) => {
  const mobile = mode === 'mobile'
  return {
    root: mobile ? resolve(__dirname, 'mobile') : undefined,
    plugins: [react()],
    base: mobile ? '/mobile/' : './',
    optimizeDeps: {
      // MapLibre resolves its module worker relative to the package entry.
      // Pre-bundling moves that entry into .vite/deps without its worker file.
      exclude: ['maplibre-gl'],
    },
    build: mobile ? { outDir: resolve(__dirname, 'mobile-dist'), emptyOutDir: true } : undefined,
    server: { port: 5173 },
    test: {
      exclude: ['e2e/**', 'node_modules/**', 'dist/**', 'mobile-dist/**'],
    },
  }
})
