const isMobileRemote = typeof window !== 'undefined' && window.location.pathname.startsWith('/mobile')
export const API_BASE_URL = isMobileRemote ? window.location.origin : 'http://127.0.0.1:8787'
export const WS_URL = isMobileRemote
  ? `${window.location.protocol === 'https:' ? 'wss' : 'ws'}://${window.location.host}/ws/mobile`
  : 'ws://127.0.0.1:8787/ws/status'

export function authHeaders(headers: Record<string, string> = {}): Record<string, string> {
  const session = isMobileRemote ? sessionStorage.getItem('arcwayfarer.mobile.session') : null
  return session ? { ...headers, Authorization: `Bearer ${session}` } : headers
}

export type DeviceStatus = 'ready' | 'mounting' | 'tunnel_required' | 'error'

export type Device = {
  udid: string
  name: string
  ios_version: string
  transport: 'lockdown' | 'rsd'
  status: DeviceStatus
  detail: string | null
  /** Physical discovery path, when supplied by newer backends. */
  connection_type?: 'usb' | 'wifi' | 'unknown'
}

export type MobilePairing = { url: string; pin: string; expires_in: number; qr_data_url: string }
export type MobileRemoteStatus = { paired_sessions: number; connected_phones: number }
export type DeviceDiscoveryDiagnostic = {
  code: 'usb_discovery_failed'
  occurred_at: string
  error_type: string
  message: string
  python_version: string
  platform: string
  pymobiledevice3_version: string
}

export async function createMobilePairing(): Promise<MobilePairing> {
  return postJsonWithResponse('/api/mobile/pairings', {})
}

export function getMobileRemoteStatus(): Promise<MobileRemoteStatus> {
  return getJson('/api/mobile/status')
}

export function revokeMobileSessions(): Promise<void> {
  return deleteJson('/api/mobile/sessions')
}

export async function checkHealth(): Promise<boolean> {
  try {
    const res = await fetch(`${API_BASE_URL}/health`)
    return res.ok
  } catch {
    return false
  }
}

export async function listDevices({ includeWifi = false }: { includeWifi?: boolean } = {}): Promise<Device[]> {
  const controller = new AbortController()
  const timeoutId = setTimeout(() => controller.abort(), 15000)
  try {
    // USB-only is the backend default, so omit the query in that common path.
    // It also keeps older clients' request URL stable for integrations.
    const query = includeWifi ? '?include_wifi=true' : ''
    const res = await fetch(`${API_BASE_URL}/api/devices${query}`, {
      headers: authHeaders(),
      signal: controller.signal,
    })
    if (!res.ok) throw new Error(`Failed to list devices (${res.status})`)
    const devices = await res.json() as Device[]
    // The API filter is intentionally duplicated here until all packaged
    // backend versions understand include_wifi. Unknown is retained for
    // backwards compatibility with older backends that did not report a
    // physical connection type.
    return includeWifi ? devices : devices.filter((device) => device.connection_type !== 'wifi')
  } catch (err: any) {
    if (err.name === 'AbortError') {
      throw new Error('Device scan timed out (15s). Please check device connection.')
    }
    throw err
  } finally {
    clearTimeout(timeoutId)
  }
}

export async function getDeviceDiscoveryDiagnostic(): Promise<DeviceDiscoveryDiagnostic | null> {
  const response = await getJson<{ usb_discovery: DeviceDiscoveryDiagnostic | null }>('/api/devices/diagnostics')
  return response.usb_discovery
}

async function getJson<T>(path: string): Promise<T> {
  const res = await fetch(`${API_BASE_URL}${path}`, { headers: authHeaders() })
  if (!res.ok) throw new Error(`Request failed (${res.status})`)
  return res.json()
}

async function deleteJson(path: string): Promise<void> {
  const res = await fetch(`${API_BASE_URL}${path}`, { method: 'DELETE', headers: authHeaders() })
  const payload = await res.json().catch(() => null)
  if (!res.ok) {
    throw new Error(payload?.detail ?? `Request failed (${res.status})`)
  }
}

export function amfiRevealDeveloperMode(udid: string): Promise<{ status: string }> {
  return postJsonWithResponse(`/api/devices/${udid}/amfi/reveal-developer-mode`, {})
}

async function postJsonWithResponse<T>(path: string, body: unknown, externalSignal?: AbortSignal): Promise<T> {
  const controller = new AbortController()
  const timeoutId = setTimeout(() => controller.abort(), 15000)
  const abortFromExternalSignal = () => controller.abort(externalSignal?.reason)
  if (externalSignal?.aborted) abortFromExternalSignal()
  else externalSignal?.addEventListener('abort', abortFromExternalSignal, { once: true })
  try {
    const res = await fetch(`${API_BASE_URL}${path}`, {
      method: 'POST',
      headers: authHeaders({ 'Content-Type': 'application/json' }),
      body: JSON.stringify(body),
      signal: controller.signal,
    })
    const payload = await res.json().catch(() => null)
    if (!res.ok) {
      throw new Error(payload?.detail ?? `Request failed (${res.status})`)
    }
    return payload as T
  } catch (err: any) {
    if (err.name === 'AbortError') {
      if (externalSignal?.aborted) throw err
      throw new Error('Request timed out (15s). Please check device connection.')
    }
    throw err
  } finally {
    clearTimeout(timeoutId)
    externalSignal?.removeEventListener('abort', abortFromExternalSignal)
  }
}

async function postJson(path: string, body: unknown): Promise<void> {
  await postJsonWithResponse(path, body)
}

async function putJsonWithResponse<T>(path: string, body: unknown): Promise<T> {
  const res = await fetch(`${API_BASE_URL}${path}`, {
    method: 'PUT',
    headers: authHeaders({ 'Content-Type': 'application/json' }),
    body: JSON.stringify(body),
  })
  const payload = await res.json().catch(() => null)
  if (!res.ok) throw new Error(payload?.detail ?? `Request failed (${res.status})`)
  return payload as T
}

export function setLocation(udid: string, lat: number, lng: number): Promise<void> {
  return postJson('/api/location/set', { udid, lat, lng })
}

export function clearLocation(udid: string): Promise<void> {
  return postJson('/api/location/clear', { udid })
}

export function goldDitto(udid: string, lat: number, lng: number): Promise<void> {
  return postJson('/api/location/gold-ditto', { udid, lat, lng })
}

export type NavMode = 'walk' | 'bike' | 'drive'
export type LatLng = { lat: number; lng: number }

export function previewNavigate(
  navMode: NavMode,
  start: LatLng,
  end: LatLng,
  signal?: AbortSignal
): Promise<{ status: string; route: LatLng[]; distance_m: number }> {
  return postJsonWithResponse('/api/navigate/preview', {
    nav_mode: navMode,
    start,
    end,
  }, signal)
}

export async function getNavModeSpeeds(): Promise<Record<NavMode, number>> {
  const res = await fetch(`${API_BASE_URL}/api/navigate/modes`, { headers: authHeaders() })
  if (!res.ok) throw new Error(`Failed to load nav modes (${res.status})`)
  return res.json()
}

export function startNavigate(
  udid: string,
  navMode: NavMode,
  start: LatLng,
  end: LatLng,
  customSpeedKmh?: number
): Promise<{ status: string; route: LatLng[] }> {
  return postJsonWithResponse('/api/navigate/start', {
    udid,
    nav_mode: navMode,
    start,
    end,
    custom_speed_kmh: customSpeedKmh ?? null,
  })
}

export function stopNavigate(udid: string): Promise<void> {
  return postJson('/api/navigate/stop', { udid })
}

export function pauseNavigate(udid: string): Promise<void> {
  return postJson('/api/navigate/pause', { udid })
}

export function resumeNavigate(udid: string): Promise<void> {
  return postJson('/api/navigate/resume', { udid })
}

export type StationPause = { enabled: boolean; min: number; max: number }

export function startRouteLoop(
  udid: string,
  navMode: NavMode,
  waypoints: LatLng[],
  stationPause: StationPause,
  customSpeedKmh?: number,
  straightLine: boolean = false
): Promise<{ status: string; route: LatLng[]; legs: LatLng[][] }> {
  return postJsonWithResponse('/api/route-loop/start', {
    udid,
    nav_mode: navMode,
    waypoints,
    pause_enabled: stationPause.enabled,
    pause_min: stationPause.min,
    pause_max: stationPause.max,
    straight_line: straightLine,
    custom_speed_kmh: customSpeedKmh ?? null,
  })
}

export function stopRouteLoop(udid: string): Promise<void> {
  return postJson('/api/route-loop/stop', { udid })
}

export function pauseRouteLoop(udid: string): Promise<void> {
  return postJson('/api/route-loop/pause', { udid })
}

export function resumeRouteLoop(udid: string): Promise<void> {
  return postJson('/api/route-loop/resume', { udid })
}

export type MultiStopOptions = {
  straightLine?: boolean
  jumpMode?: boolean
  jumpPreDelay?: number
  jumpPostDelay?: number
  customSpeedKmh?: number
}

export function startMultiStop(
  udid: string,
  navMode: NavMode,
  waypoints: LatLng[],
  stationPause: StationPause,
  options: MultiStopOptions = {}
): Promise<{ status: string; route: LatLng[]; legs: LatLng[][] }> {
  return postJsonWithResponse('/api/multi-stop/start', {
    udid,
    nav_mode: navMode,
    mode: 'basic',
    waypoints,
    pause_enabled: stationPause.enabled,
    pause_min: stationPause.min,
    pause_max: stationPause.max,
    straight_line: options.straightLine ?? false,
    jump_mode: options.jumpMode ?? false,
    jump_pre_delay: options.jumpPreDelay ?? 0,
    jump_post_delay: options.jumpPostDelay ?? 0,
    custom_speed_kmh: options.customSpeedKmh ?? null,
  })
}

export type FlowerOptions = {
  radius_m: number
  circles: number
  segments: number
  path_strategy: 'center_spiral' | 'perimeter'
  inner_radius_m: number | null
  jitter_m: number
  pre_wait_seconds: number
  post_wait_seconds: number
  route_type: 'stop_at_end' | 'return_to_start' | 'loop_forever'
  rounds: number | 'infinite'
}

/** Starts Flower mode through the multi-stop controller. Flower is a mode
 * payload, rather than a separate endpoint, so older multi-stop controls
 * remain untouched. */
export function startFlower(
  udid: string,
  navMode: NavMode,
  waypoints: LatLng[],
  flower: FlowerOptions,
  options: Pick<MultiStopOptions, 'straightLine' | 'jumpMode' | 'customSpeedKmh'> = {},
): Promise<{ status: string; route: LatLng[]; legs: LatLng[][] }> {
  return postJsonWithResponse('/api/multi-stop/start', {
    udid,
    nav_mode: navMode,
    mode: 'flower',
    waypoints,
    flower,
    straight_line: options.straightLine ?? false,
    jump_mode: options.jumpMode ?? false,
    custom_speed_kmh: options.customSpeedKmh ?? null,
  })
}

export function stopMultiStop(udid: string): Promise<void> {
  return postJson('/api/multi-stop/stop', { udid })
}

export function skipFlower(udid: string): Promise<void> {
  return postJson('/api/multi-stop/skip', { udid })
}

export function pauseMultiStop(udid: string): Promise<void> {
  return postJson('/api/multi-stop/pause', { udid })
}

export function resumeMultiStop(udid: string): Promise<void> {
  return postJson('/api/multi-stop/resume', { udid })
}

export function startRandomWalk(
  udid: string,
  navMode: NavMode,
  center: LatLng,
  radiusM: number,
  stationPause: StationPause,
  customSpeedKmh?: number,
  straightLine = true
): Promise<void> {
  return postJson('/api/random-walk/start', {
    udid,
    nav_mode: navMode,
    center,
    radius_m: radiusM,
    pause_enabled: stationPause.enabled,
    pause_min: stationPause.min,
    pause_max: stationPause.max,
    custom_speed_kmh: customSpeedKmh ?? null,
    straight_line: straightLine,
  })
}

export function stopRandomWalk(udid: string): Promise<void> {
  return postJson('/api/random-walk/stop', { udid })
}

export function pauseRandomWalk(udid: string): Promise<void> {
  return postJson('/api/random-walk/pause', { udid })
}

export function resumeRandomWalk(udid: string): Promise<void> {
  return postJson('/api/random-walk/resume', { udid })
}

export function startJoystick(
  udid: string,
  navMode: NavMode,
  lat: number,
  lng: number,
  customSpeedKmh?: number
): Promise<void> {
  return postJson('/api/location/joystick/start', {
    udid,
    nav_mode: navMode,
    lat,
    lng,
    custom_speed_kmh: customSpeedKmh ?? null,
  })
}

export function stopJoystick(udid: string): Promise<void> {
  return postJson('/api/location/joystick/stop', { udid })
}

export type HistoryKind = 'teleport' | 'navigate' | 'route_loop' | 'multi_stop' | 'random_walk' | 'joystick'

export type HistoryEntry = {
  lat: number
  lng: number
  kind: HistoryKind
  name: string | null
  ts: number
}

export function listHistory(): Promise<HistoryEntry[]> {
  return getJson('/api/history')
}

export function pushHistory(entry: { lat: number; lng: number; kind: HistoryKind; name?: string }): Promise<HistoryEntry> {
  return postJsonWithResponse('/api/history', entry)
}

export function clearHistory(): Promise<void> {
  return deleteJson('/api/history')
}

export type Favorite = {
  id: string
  name: string
  lat: number
  lng: number
  created_at: number
  group: string
  notes: string
  order: number
}

export type FavoriteExportItem = {
  name: string
  lat: number
  lng: number
  group: string
  notes: string
  created_at: number
  order: number
}

export type FavoriteExportDocument = {
  format: 'arcwayfarer-favorites'
  schema_version: 1
  exported_at: string
  groups: string[]
  favorites: FavoriteExportItem[]
}

export type FavoriteImportPreview = {
  total: number
  additions: number
  duplicates: number
  groups_to_add: string[]
}

export type FavoriteImportResult = FavoriteImportPreview & {
  imported: number
}

export function listFavorites(): Promise<Favorite[]> {
  return getJson('/api/favorites')
}

export function listFavoriteGroups(): Promise<string[]> {
  return getJson('/api/favorites/groups')
}

export function exportFavorites(groups: string[]): Promise<FavoriteExportDocument> {
  const params = new URLSearchParams()
  groups.forEach((group) => params.append('groups', group))
  return getJson(`/api/favorites/export?${params.toString()}`)
}

export function previewFavoriteImport(document: FavoriteExportDocument): Promise<FavoriteImportPreview> {
  return postJsonWithResponse('/api/favorites/import/preview', document)
}

export function importFavorites(document: FavoriteExportDocument): Promise<FavoriteImportResult> {
  return postJsonWithResponse('/api/favorites/import', document)
}

export function addFavoriteGroup(name: string): Promise<string> {
  return postJsonWithResponse('/api/favorites/groups', { name })
}

export function addFavorite(input: { name: string; lat: number; lng: number; group?: string; notes?: string }): Promise<Favorite> {
  return postJsonWithResponse('/api/favorites', input)
}

export function updateFavorite(id: string, input: { name?: string; group?: string; notes?: string }): Promise<Favorite> {
  return putJsonWithResponse(`/api/favorites/${id}`, input)
}

export function reorderFavorites(items: { id: string; order: number }[]): Promise<Favorite[]> {
  return putJsonWithResponse('/api/favorites/reorder', { items })
}

export function deleteFavorite(id: string): Promise<void> {
  return deleteJson(`/api/favorites/${id}`)
}
