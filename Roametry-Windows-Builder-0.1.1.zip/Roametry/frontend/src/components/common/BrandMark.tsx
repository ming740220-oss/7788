type Props = {
  size?: number
}

export function BrandMark({ size = 34 }: Props) {
  return (
    <svg
      className="roametry-brand-mark"
      width={size}
      height={size}
      viewBox="0 0 64 64"
      role="img"
      aria-label="Roametry"
    >
      <defs>
        <linearGradient id="roametry-mark-gradient" x1="8" y1="6" x2="55" y2="59" gradientUnits="userSpaceOnUse">
          <stop stopColor="#5577ff" />
          <stop offset="1" stopColor="#42e8c8" />
        </linearGradient>
      </defs>
      <rect x="3" y="3" width="58" height="58" rx="18" fill="#0b1020" />
      <path
        d="M20 47V18h15.5c7.2 0 11.5 4.2 11.5 10.4 0 5.2-3 8.9-8.1 10L47 47M20 35h13.8"
        fill="none"
        stroke="url(#roametry-mark-gradient)"
        strokeWidth="5"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <circle cx="47" cy="47" r="4.5" fill="#42e8c8" />
    </svg>
  )
}
