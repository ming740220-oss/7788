// @vitest-environment jsdom
import { cleanup, fireEvent, render, screen, waitFor } from '@testing-library/react'
import { MantineProvider } from '@mantine/core'
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest'
import { clearLocation } from '../../services/api'
import { TeleportPanel } from './TeleportPanel'
import type { PanelProps } from './types'

vi.mock('../../i18n', () => ({ useT: () => (key: string) => key }))
vi.mock('../../services/api', () => ({
  clearLocation: vi.fn().mockResolvedValue(undefined),
  goldDitto: vi.fn(),
  pushHistory: vi.fn().mockResolvedValue(undefined),
  setLocation: vi.fn(),
}))
vi.mock('./FavoriteButton', () => ({ FavoriteButton: () => null }))

describe('TeleportPanel restore location', () => {
  beforeEach(() => {
    Object.defineProperty(window, 'matchMedia', {
      writable: true,
      value: vi.fn().mockImplementation((query: string) => ({
        matches: false,
        media: query,
        onchange: null,
        addListener: vi.fn(),
        removeListener: vi.fn(),
        addEventListener: vi.fn(),
        removeEventListener: vi.fn(),
        dispatchEvent: vi.fn(),
      })),
    })
    vi.stubGlobal('ResizeObserver', class {
      observe() {}
      unobserve() {}
      disconnect() {}
    })
  })

  afterEach(() => {
    cleanup()
    vi.clearAllMocks()
  })

  const props: PanelProps = {
    deviceId: 'device-1',
    device: { status: 'ready', detail: '' } as PanelProps['device'],
    deviceState: 'idle',
    point: { lat: 25.033, lng: 121.5654 },
    livePosition: { lat: 25.033, lng: 121.5654 },
    liveEtaSeconds: null,
    liveStopIndex: null,
    setPoint: vi.fn(),
    requestPoint: vi.fn(),
    clearPoint: vi.fn(),
    setOverlay: vi.fn(),
    requestFlyTo: vi.fn(),
    sendWs: vi.fn(),
  }

  it('keeps the last teleport coordinates visible after restoring real GPS', async () => {
    render(<MantineProvider><TeleportPanel {...props} /></MantineProvider>)

    const coordinateInput = screen.getByRole('textbox', { name: 'teleport.coordinate.label' }) as HTMLInputElement
    expect(coordinateInput.value).toBe('25.0330,121.5654')

    fireEvent.click(screen.getByRole('button', { name: 'teleport.action.clear' }))

    await waitFor(() => expect(clearLocation).toHaveBeenCalledWith('device-1'))
    expect(coordinateInput.value).toBe('25.0330,121.5654')
    expect(screen.getByText(/teleport\.status\.clear_success_coordinate/)).toBeDefined()
    expect(props.setPoint).not.toHaveBeenCalledWith(null)
    expect(props.clearPoint).not.toHaveBeenCalled()
  })
})
